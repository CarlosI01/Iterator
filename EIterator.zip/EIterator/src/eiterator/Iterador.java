/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package eiterator;

/**
 *
 * @author MAWIL
 */
public interface Iterador {
    public Object siguiente();
    public boolean tieneSiguiente();
}
